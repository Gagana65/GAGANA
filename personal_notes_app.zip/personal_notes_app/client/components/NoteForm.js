import React, { useState, useEffect } from 'react';

const NoteForm = ({ fetchNotes, currentNote, setCurrentNote }) => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');

  useEffect(() => {
    if (currentNote) {
      setTitle(currentNote.title);
      setContent(currentNote.content);
    }
  }, [currentNote]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const method = currentNote ? 'PUT' : 'POST';
    const url = currentNote ? `/notes/${currentNote._id}` : '/notes';

    await fetch(`http://localhost:5000${url}`, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, content }),
    });

    setTitle('');
    setContent('');
    setCurrentNote(null);
    fetchNotes();
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        placeholder="Title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        required
      />
      <textarea
        placeholder="Content"
        value={content}
        onChange={(e) => setContent(e.target.value)}
        required
      />
      <button type="submit">{currentNote ? 'Update' : 'Add'} Note</button>
    </form>
  );
};

export default NoteForm;
